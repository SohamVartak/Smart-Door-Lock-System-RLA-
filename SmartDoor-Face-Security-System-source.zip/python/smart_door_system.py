import os

import json

import time

import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from datetime import datetime

import tkinter as tk

from tkinter import ttk, messagebox, simpledialog



import cv2

from PIL import Image, ImageTk



APP_DIR = os.path.dirname(os.path.abspath(__file__))

FACES_DIR = os.path.join(APP_DIR, "faces")

RECORDINGS_DIR = os.path.join(APP_DIR, "recordings")

MODEL_PATH = os.path.join(APP_DIR, "face_model.yml")

LABELS_PATH = os.path.join(APP_DIR, "face_labels.json")

CASCADE_FILENAME = "haarcascade_frontalface_default.xml"

CASCADE_LOCAL = os.path.join(APP_DIR, CASCADE_FILENAME)

FACE_SIZE = (200, 200)
FACE_CLAHE = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))

SAMPLES_TO_CAPTURE = 45

SAMPLE_INTERVAL_SECONDS = 0.35

UNKNOWN_THRESHOLD = 75  # LBPH distance: lower is a closer match

FAILURES_TO_RECORD = 1



os.makedirs(FACES_DIR, exist_ok=True)

os.makedirs(RECORDINGS_DIR, exist_ok=True)





def load_cascade():

    """Load the face detector from the project folder first, then OpenCV data."""

    candidates = [CASCADE_LOCAL]

    try:

        candidates.append(os.path.join(cv2.data.haarcascades, CASCADE_FILENAME))

    except Exception:

        pass

    for path in candidates:

        if os.path.isfile(path):

            detector = cv2.CascadeClassifier(path)

            if not detector.empty():

                return detector

    raise FileNotFoundError(

        "Could not find " + CASCADE_FILENAME + ". Download it from "

        "https://raw.githubusercontent.com/opencv/opencv/4.x/data/haarcascades/haarcascade_frontalface_default.xml "

        "and save it beside smart_door_system.py."

    )





def get_recognizer():

    if not hasattr(cv2, "face") or not hasattr(cv2.face, "LBPHFaceRecognizer_create"):

        raise RuntimeError("OpenCV face module is unavailable. Install opencv-contrib-python in this .venv.")

    return cv2.face.LBPHFaceRecognizer_create()


def prepare_face(face_image):
    """Normalize lighting and size consistently for both training and prediction."""
    if face_image is None or face_image.size == 0:
        return None
    if len(face_image.shape) == 3:
        face_image = cv2.cvtColor(face_image, cv2.COLOR_BGR2GRAY)
    resized = cv2.resize(face_image, FACE_SIZE, interpolation=cv2.INTER_CUBIC)
    return FACE_CLAHE.apply(resized)





class SecurityEventServer:
    """Local HTTP API for the Android app. Use only on a trusted private network."""
    def __init__(self, dashboard, host="0.0.0.0", port=8765):
        self.dashboard = dashboard
        self.server = None
        self.thread = None
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def _send_json(self, status, payload):
                body = json.dumps(payload).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self):
                path = self.path.split("?", 1)[0].rstrip("/") or "/"
                if path == "/health":
                    self._send_json(200, {"status": "ok", "service": "SmartDoor"})
                elif path == "/status":
                    self._send_json(200, owner.dashboard.get_api_status())
                elif path == "/face-check":
                    state = owner.dashboard.get_api_status()
                    now = time.time()
                    current_state = state.get("face_state", "NO_FACE")
                    current_person = state.get("recognized_person", "")
                    last_recognition_time = float(state.get("last_recognition_update", 0.0) or 0.0)
                    last_recognized_person = str(state.get("last_recognized_person", "") or "")

                    # A camera stream can drop a single frame or the user may tap between
                    # two processed frames. Retain a successful match for a very short
                    # grace period, but never carry it over an UNKNOWN or REGISTERING frame.
                    recognition_age = now - last_recognition_time
                    grace_seconds = 1.5
                    if (
                        current_state == "NO_FACE"
                        and last_recognized_person
                        and 0 <= recognition_age <= grace_seconds
                    ):
                        current_state = "RECOGNIZED"
                        current_person = last_recognized_person

                    fresh = bool(current_state == "RECOGNIZED" and current_person and 0 <= recognition_age <= grace_seconds)
                    eligible = bool(
                        state.get("camera_connected")
                        and state.get("model_ready")
                        and current_state == "RECOGNIZED"
                        and fresh
                        and current_person
                    )
                    # For a rejected face, use the most recently processed camera frame
                    # to distinguish UNKNOWN from an empty frame. This is separate from
                    # `fresh`, which is reserved for a valid recognized-person match.
                    try:
                        last_frame_update = float(state.get("last_face_update", 0.0) or 0.0)
                    except (TypeError, ValueError):
                        last_frame_update = 0.0
                    frame_age = now - last_frame_update if last_frame_update else float("inf")
                    face_state_fresh = bool(
                        state.get("camera_connected")
                        and 0 <= frame_age <= 2.0
                        and current_state in ("UNKNOWN", "RECOGNIZED")
                    )
                    state["face_state"] = current_state
                    state["recognized_person"] = current_person
                    state["eligible"] = eligible
                    state["fresh"] = fresh
                    state["face_state_fresh"] = face_state_fresh
                    state["recognition_age_seconds"] = round(max(0.0, recognition_age), 3) if last_recognition_time else None
                    state["frame_age_seconds"] = round(max(0.0, frame_age), 3) if last_frame_update else None
                    self._send_json(200, state)
                else:
                    self._send_json(404, {"error": "not_found"})

            def do_POST(self):
                path = self.path.split("?", 1)[0].rstrip("/")
                if path not in ("/failed-auth", "/recording/start", "/recording/stop"):
                    self._send_json(404, {"error": "not_found"})
                    return
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                    if length < 0 or length > 8192:
                        self._send_json(413, {"error": "payload_too_large"})
                        return
                    raw = self.rfile.read(length) if length else b"{}"
                    payload = json.loads(raw.decode("utf-8"))
                    if not isinstance(payload, dict):
                        raise ValueError("Expected a JSON object")

                    if path == "/failed-auth":
                        event = str(payload.get("event", "failed_auth"))[:80]
                        method = str(payload.get("method", "fingerprint"))[:40]
                        owner.dashboard.root.after(
                            0, owner.dashboard.handle_external_failed_auth, method, event
                        )
                        self._send_json(202, {"received": True, "action": "failed_auth_logged"})
                    elif path == "/recording/start":
                        owner.dashboard.root.after(0, owner.dashboard.request_manual_recording)
                        self._send_json(202, {"received": True, "action": "recording_start_requested"})
                    else:
                        owner.dashboard.root.after(0, owner.dashboard.stop_recording)
                        self._send_json(202, {"received": True, "action": "recording_stop_requested"})
                except Exception:
                    self._send_json(400, {"error": "invalid_request"})

            def log_message(self, fmt, *args):
                return

        try:
            self.server = ThreadingHTTPServer((host, port), Handler)
            self.server.daemon_threads = True
            self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
            self.thread.start()
        except OSError as exc:
            self.server = None
            raise RuntimeError(
                f"Could not start security API on port {port}: {exc}. "
                "Close any other program using port 8765 and restart."
            ) from exc

    def close(self):
        if self.server is not None:
            self.server.shutdown()
            self.server.server_close()
            self.server = None


class SmartDoorDashboard:

    def __init__(self, root):

        self.root = root

        self.root.title("SmartDoor | Face Security Dashboard")

        self.root.geometry("1220x780")

        self.root.minsize(980, 650)

        self.root.configure(bg="#0b1220")

        self.closing = False



        self.camera = None

        self.camera_url = tk.StringVar(value="http://PHONE_IP:8080/video")

        self.camera_running = False

        self.frame_lock = threading.Lock()

        self.latest_frame = None

        self.video_job = None



        self.detector = load_cascade()

        self.recognizer = get_recognizer()

        self.label_names = {}

        self.model_ready = False

        self.registration_running = False

        self.registration_name = None

        self.registration_samples = []

        self.last_sample_time = 0.0

        self.failed_attempts = 0

        self.unknown_in_current_session = False

        self.last_face_seen = 0.0

        self.recording = False

        self.video_writer = None

        self.recording_path = None

        self.last_record_start = 0.0
        self.pending_external_record = False

        self.current_status = "CAMERA OFFLINE"

        self.status_var = tk.StringVar(value=self.current_status)

        self.model_var = tk.StringVar(value="MODEL: NOT TRAINED")

        self.failures_var = tk.StringVar(value="0 / 3")

        self.record_var = tk.StringVar(value="NOT RECORDING")

        self.person_var = tk.StringVar(value="No face detected")

        # Plain-data snapshot read by HTTP worker threads; Tk objects are never accessed there.
        self.api_status_lock = threading.Lock()
        self.api_status = {
            "camera_connected": False,
            "model_ready": False,
            "face_state": "NO_FACE",
            "recognized_person": "",
            "last_face_update": 0.0,
            "last_recognized_person": "",
            "last_recognition_update": 0.0,
            "recording": False,
            "recording_file": "",
            "failed_attempts": 0,
        }

        self._build_ui()

        self._load_model_if_available()

        self.root.protocol("WM_DELETE_WINDOW", self.close)

        self._refresh_video()

        self._log("Dashboard started. Connect your phone camera to begin.")
        self.event_server = SecurityEventServer(self)
        self._log("Android API listening on port 8765: /status, /face-check, /recording/start, /recording/stop, /failed-auth.")



    def _update_api_status(self, **fields):
        with self.api_status_lock:
            self.api_status.update(fields)

    def get_api_status(self):
        with self.api_status_lock:
            return dict(self.api_status)

    def _build_ui(self):

        style = ttk.Style()

        try:

            style.theme_use("clam")

        except tk.TclError:

            pass

        style.configure("TButton", font=("Segoe UI", 10), padding=8)



        header = tk.Frame(self.root, bg="#111c2f", padx=22, pady=16)

        header.pack(fill="x")

        tk.Label(header, text="SMARTDOOR", font=("Segoe UI", 23, "bold"), fg="#f8fafc", bg="#111c2f").pack(side="left")

        tk.Label(header, text="FACE SECURITY SYSTEM  /  LOCAL PROTOTYPE", font=("Segoe UI", 9, "bold"), fg="#8ea3c0", bg="#111c2f").pack(side="left", padx=18, pady=(7, 0))

        tk.Label(header, textvariable=self.status_var, font=("Segoe UI", 10, "bold"), fg="#fbbf24", bg="#111c2f").pack(side="right", pady=5)



        main = tk.Frame(self.root, bg="#0b1220", padx=18, pady=16)

        main.pack(fill="both", expand=True)

        left = tk.Frame(main, bg="#111c2f", padx=14, pady=14)

        left.pack(side="left", fill="both", expand=True, padx=(0, 12))

        right = tk.Frame(main, bg="#111c2f", padx=16, pady=14, width=330)

        right.pack(side="right", fill="y")

        right.pack_propagate(False)



        tk.Label(left, text="LIVE CAMERA", font=("Segoe UI", 12, "bold"), fg="#e2e8f0", bg="#111c2f").pack(anchor="w")

        self.video_label = tk.Label(left, text="CAMERA OFFLINE\nConnect your phone stream below", font=("Segoe UI", 15, "bold"), fg="#718096", bg="#050914", width=78, height=22)

        self.video_label.pack(fill="both", expand=True, pady=(10, 12))



        tk.Label(left, text="CAMERA SOURCE", font=("Segoe UI", 9, "bold"), fg="#8ea3c0", bg="#111c2f").pack(anchor="w")

        source_row = tk.Frame(left, bg="#111c2f")

        source_row.pack(fill="x", pady=(5, 4))

        self.url_entry = tk.Entry(source_row, textvariable=self.camera_url, font=("Consolas", 10), bg="#0b1220", fg="#e2e8f0", insertbackground="white", relief="flat")

        self.url_entry.pack(side="left", fill="x", expand=True, ipady=9, padx=(0, 8))

        self.connect_button = ttk.Button(source_row, text="Connect Camera", command=self.connect_camera)

        self.connect_button.pack(side="right")

        tk.Label(left, text="Keep IP Webcam running on your phone. Use the exact stream URL that works in Chrome.", font=("Segoe UI", 9), fg="#718096", bg="#111c2f").pack(anchor="w")



        tk.Label(right, text="SECURITY OVERVIEW", font=("Segoe UI", 12, "bold"), fg="#e2e8f0", bg="#111c2f").pack(anchor="w", pady=(0, 12))

        self._metric(right, "FACE MODEL", self.model_var)

        self._metric(right, "FAILED UNKNOWN SESSIONS", self.failures_var)

        self._metric(right, "RECORDING", self.record_var)

        self._metric(right, "DETECTION", self.person_var)



        tk.Label(right, text="FACE REGISTRATION", font=("Segoe UI", 11, "bold"), fg="#e2e8f0", bg="#111c2f").pack(anchor="w", pady=(20, 8))

        ttk.Button(right, text="Register New Face", command=self.start_registration).pack(fill="x", pady=3)

        ttk.Button(right, text="Train / Retrain Model", command=self.train_model).pack(fill="x", pady=3)

        ttk.Button(right, text="Reset Failed Attempts", command=self.reset_failures).pack(fill="x", pady=3)

        self.record_button = ttk.Button(right, text="Stop Recording", command=self.stop_recording, state="disabled")

        self.record_button.pack(fill="x", pady=(3, 0))



        tk.Label(right, text="SECURITY EVENT LOG", font=("Segoe UI", 11, "bold"), fg="#e2e8f0", bg="#111c2f").pack(anchor="w", pady=(20, 7))

        log_frame = tk.Frame(right, bg="#0b1220")

        log_frame.pack(fill="both", expand=True)

        self.log_text = tk.Text(log_frame, height=10, wrap="word", bg="#0b1220", fg="#b9c7dc", insertbackground="white", relief="flat", font=("Consolas", 9), state="disabled")

        self.log_text.pack(side="left", fill="both", expand=True)

        scrollbar = ttk.Scrollbar(log_frame, command=self.log_text.yview)

        scrollbar.pack(side="right", fill="y")

        self.log_text.configure(yscrollcommand=scrollbar.set)

        footer = tk.Label(self.root, text="Prototype only • Face recognition can be fooled by photos/videos • Recording should be visible and authorized", bg="#0b1220", fg="#718096", font=("Segoe UI", 9), pady=7)

        footer.pack(fill="x")



    def _metric(self, parent, title, variable):

        card = tk.Frame(parent, bg="#17243a", padx=10, pady=9)

        card.pack(fill="x", pady=4)

        tk.Label(card, text=title, font=("Segoe UI", 8, "bold"), fg="#8ea3c0", bg="#17243a").pack(anchor="w")

        tk.Label(card, textvariable=variable, font=("Segoe UI", 11, "bold"), fg="#f8fafc", bg="#17243a").pack(anchor="w", pady=(3, 0))



    def _log(self, message):

        if not hasattr(self, "log_text"):

            return

        stamp = datetime.now().strftime("%H:%M:%S")

        self.log_text.configure(state="normal")

        self.log_text.insert("end", f"[{stamp}] {message}\n")

        self.log_text.see("end")

        self.log_text.configure(state="disabled")



    def _set_status(self, text, color=None):

        self.current_status = text

        self.status_var.set(text)

        if color:

            # Header status label is the last label in the header; update through textvariable's display only.

            pass



    def connect_camera(self):

        source = self.camera_url.get().strip()

        if not source:

            messagebox.showwarning("Camera source required", "Enter your phone's video URL, for example http://PHONE-IP:8080/video")

            return

        self._disconnect_camera(log_event=False)

        self._set_status("CONNECTING…")

        self._log("Connecting to camera stream…")

        self.connect_button.configure(state="disabled")

        threading.Thread(target=self._open_camera_worker, args=(source,), daemon=True).start()



    def _open_camera_worker(self, source):

        try:

            if source.isdigit():

                cap = cv2.VideoCapture(int(source))

            else:

                cap = cv2.VideoCapture(source, cv2.CAP_FFMPEG)

                if not cap.isOpened():

                    cap.release()

                    cap = cv2.VideoCapture(source)

            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

            opened = cap.isOpened()

            ok, frame = cap.read() if opened else (False, None)

            if not opened or not ok or frame is None:

                cap.release()

                self.root.after(0, self._camera_failed, "OpenCV could not read a frame from that URL.")

                return

            self.camera = cap

            self.camera_running = True

            with self.frame_lock:

                self.latest_frame = frame

            self.root.after(0, self._camera_connected)

        except Exception as exc:

            self.root.after(0, self._camera_failed, str(exc))



    def _camera_connected(self):

        self._update_api_status(camera_connected=True)
        self.connect_button.configure(state="normal")

        self._set_status("CAMERA ONLINE")

        self._log("Camera connected. Live detection is active.")



    def _camera_failed(self, reason):

        self._update_api_status(camera_connected=False, face_state="NO_FACE", recognized_person="")
        self.connect_button.configure(state="normal")

        self._set_status("CAMERA OFFLINE")

        self._log("Camera connection failed: " + reason)

        messagebox.showerror("Camera connection failed", reason + "\n\nConfirm the phone stream works in Chrome and that the URL is correct.")



    def _disconnect_camera(self, log_event=True):

        self.camera_running = False
        self._update_api_status(camera_connected=False, face_state="NO_FACE", recognized_person="")

        cap = self.camera

        self.camera = None

        if cap is not None:

            try:

                cap.release()

            except Exception:

                pass

        if log_event:

            self._log("Camera disconnected.")

        self._set_status("CAMERA OFFLINE")



    def _load_model_if_available(self):

        if os.path.isfile(MODEL_PATH) and os.path.isfile(LABELS_PATH):

            try:

                with open(LABELS_PATH, "r", encoding="utf-8") as file:

                    self.label_names = {int(k): v for k, v in json.load(file).items()}

                self.recognizer.read(MODEL_PATH)

                self.model_ready = True
                self._update_api_status(model_ready=True)

                self.model_var.set(f"MODEL: READY ({len(self.label_names)} people)")

                self._log("Saved face model loaded.")

            except Exception as exc:

                self.model_ready = False
                self._update_api_status(model_ready=False)

                self.model_var.set("MODEL: NOT TRAINED")

                self._log("Could not load saved model: " + str(exc))

        else:

            self.model_var.set("MODEL: NOT TRAINED")
            self._update_api_status(model_ready=False)



    def start_registration(self):

        if not self.camera_running:

            messagebox.showinfo("Connect camera first", "Connect your phone camera before registering a face.")

            return

        name = simpledialog.askstring("Register face", "Name or label for this person:", parent=self.root)

        if not name or not name.strip():

            return

        safe_name = "".join(ch for ch in name.strip() if ch.isalnum() or ch in " _-").strip()

        if not safe_name:

            messagebox.showwarning("Invalid name", "Please use letters or numbers in the label.")

            return

        self.registration_name = safe_name

        self.registration_samples = []

        self.registration_running = True

        self.last_sample_time = 0

        self._log(f"Registration started for '{safe_name}'. Look at the camera and move your head slightly.")

        self.person_var.set(f"Registering: 0/{SAMPLES_TO_CAPTURE}")



    def _save_registration_sample(self, gray, face_rect):

        if not self.registration_running:

            return

        now = time.time()

        if now - self.last_sample_time < SAMPLE_INTERVAL_SECONDS:

            return

        x, y, w, h = face_rect

        crop = gray[y:y + h, x:x + w]

        if crop.size == 0:

            return

        crop = cv2.resize(crop, FACE_SIZE)

        self.registration_samples.append(crop)

        self.last_sample_time = now

        self.person_var.set(f"Registering: {len(self.registration_samples)}/{SAMPLES_TO_CAPTURE}")

        if len(self.registration_samples) >= SAMPLES_TO_CAPTURE:

            person_dir = os.path.join(FACES_DIR, self.registration_name)

            os.makedirs(person_dir, exist_ok=True)

            existing = len([f for f in os.listdir(person_dir) if f.lower().endswith(".png")])

            for idx, sample in enumerate(self.registration_samples, start=1):

                cv2.imwrite(os.path.join(person_dir, f"face_{existing + idx:03d}.png"), sample)

            name = self.registration_name

            self.registration_running = False

            self.registration_samples = []

            self._log(f"Saved {SAMPLES_TO_CAPTURE} face samples for '{name}'. Training model…")

            self.train_model(show_message=False)



    def train_model(self, show_message=True):

        faces = []

        labels = []

        label_names = {}

        label_id = 0

        for person_name in sorted(os.listdir(FACES_DIR)):

            person_dir = os.path.join(FACES_DIR, person_name)

            if not os.path.isdir(person_dir):

                continue

            person_samples = 0

            for filename in sorted(os.listdir(person_dir)):

                if not filename.lower().endswith((".png", ".jpg", ".jpeg")):

                    continue

                path = os.path.join(person_dir, filename)

                image = cv2.imread(path, cv2.IMREAD_GRAYSCALE)

                if image is None:

                    continue

                prepared = prepare_face(image)
                if prepared is None:
                    continue
                faces.append(prepared)

                labels.append(label_id)

                person_samples += 1

            if person_samples:

                label_names[label_id] = person_name

                label_id += 1

        if not faces:

            self.model_ready = False
            self._update_api_status(model_ready=False)

            self.model_var.set("MODEL: NOT TRAINED")

            self._log("No registered face samples found. Register a face first.")

            if show_message:

                messagebox.showinfo("No face samples", "Register a face first, then train the model.")

            return

        try:

            self.recognizer = get_recognizer()

            self.recognizer.train(faces, __import__("numpy").array(labels, dtype="int32"))

            self.recognizer.save(MODEL_PATH)

            with open(LABELS_PATH, "w", encoding="utf-8") as file:

                json.dump({str(k): v for k, v in label_names.items()}, file, indent=2)

            self.label_names = label_names

            self.model_ready = True
            self._update_api_status(model_ready=True)

            self.model_var.set(f"MODEL: READY ({len(label_names)} people)")

            self._log(
                f"Model trained with {len(faces)} samples across {len(label_names)} people. "
                f"LBPH acceptance limit: {UNKNOWN_THRESHOLD}; lower distances are closer matches."
            )

            if show_message:

                messagebox.showinfo("Training complete", f"Model trained with {len(faces)} samples across {len(label_names)} people.")

        except Exception as exc:

            self._log("Training failed: " + str(exc))

            messagebox.showerror("Training failed", str(exc))



    def handle_external_failed_auth(self, method, event):
        """Run on the Tkinter thread when Android reports failed authentication."""
        self._log(f"ANDROID SECURITY EVENT: failed {method} authentication ({event}).")
        self.failed_attempts += 1
        self.failures_var.set(f"{self.failed_attempts} / {FAILURES_TO_RECORD}")
        if self.camera_running and self.camera is not None:
            with self.frame_lock:
                frame = self.latest_frame.copy() if self.latest_frame is not None else None
            if frame is not None:
                self._start_recording(frame)
            else:
                self.pending_external_record = True
        else:
            self.pending_external_record = True
            self._log("Camera is offline; recording will start when the camera is connected.")

    def request_manual_recording(self):
        """Start recording from the current camera frame, or queue it until a frame arrives."""
        if self.recording:
            self._log("Recording is already active; app start request ignored.")
            return
        frame = None
        if self.camera_running and self.camera is not None:
            with self.frame_lock:
                frame = self.latest_frame.copy() if self.latest_frame is not None else None
        if frame is not None:
            self._start_recording(frame)
        else:
            self.pending_external_record = True
            self._log("App requested security recording; waiting for the camera to provide a frame.")

    def reset_failures(self):

        self.failed_attempts = 0

        self.failures_var.set("0 / 3")

        self.unknown_in_current_session = False

        self._log("Failed-attempt counter reset manually.")



    def _start_recording(self, frame):

        if self.recording:

            return

        height, width = frame.shape[:2]

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        path = os.path.join(RECORDINGS_DIR, f"security_{stamp}.avi")

        fourcc = cv2.VideoWriter_fourcc(*"XVID")

        writer = cv2.VideoWriter(path, fourcc, 15.0, (width, height))

        if not writer.isOpened():

            writer.release()

            self._log("Could not start video recording. Check disk space/codec support.")

            return

        self.video_writer = writer

        self.recording = True

        self.recording_path = path
        self._update_api_status(recording=True, recording_file=os.path.basename(path))

        self.record_var.set("RECORDING ACTIVE")

        self.record_button.configure(state="normal")

        self._log(f"Security recording started: {os.path.basename(path)}")



    def stop_recording(self):

        # A manual stop also cancels any queued start request.
        self.pending_external_record = False

        if self.video_writer is not None:

            try:

                self.video_writer.release()

            except Exception:

                pass

        self.video_writer = None

        if self.recording:

            self._log(f"Recording saved: {self.recording_path}")

        self.recording = False

        self.recording_path = None
        self._update_api_status(recording=False, recording_file="")

        self.record_var.set("NOT RECORDING")

        if hasattr(self, "record_button"):

            self.record_button.configure(state="disabled")



    def _process_frame(self, frame):

        # Downscale before detection to reduce load on high-resolution phone streams.

        h, w = frame.shape[:2]

        max_w = 960

        if w > max_w:

            scale = max_w / float(w)

            frame = cv2.resize(frame, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)

        if self.pending_external_record and not self.recording:
            self._start_recording(frame)
            if self.recording:
                self.pending_external_record = False
        display = frame.copy()

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        detection_gray = cv2.equalizeHist(gray)
        detected = self.detector.detectMultiScale(
            detection_gray, scaleFactor=1.12, minNeighbors=5, minSize=(70, 70)
        )

        now = time.time()
        recognized_names = []
        unknown_seen = False
        # When enrolling, sample only the largest detected face so a bystander is
        # not accidentally added to the person's training folder.
        registration_target = max(detected, key=lambda r: int(r[2]) * int(r[3])) if len(detected) else None

        for rect in detected:
            x, y, fw, fh = rect
            raw_crop = gray[y:y + fh, x:x + fw]
            crop = prepare_face(raw_crop)
            name = "Unknown"
            color = (40, 70, 230)
            distance = None

            if self.registration_running:
                if registration_target is not None and tuple(map(int, rect)) == tuple(map(int, registration_target)):
                    self._save_registration_sample(gray, rect)
                    name = f"Registering {len(self.registration_samples)}/{SAMPLES_TO_CAPTURE}"
                    color = (0, 210, 255)
                else:
                    name = "Other face - not enrolled"
                    color = (0, 145, 255)

            elif self.model_ready:
                try:
                    if crop is None:
                        raise ValueError("Empty face crop")
                    label, distance = self.recognizer.predict(crop)
                    if label in self.label_names and distance < UNKNOWN_THRESHOLD:
                        recognized_person = self.label_names[label]
                        name = f"{recognized_person} (d={distance:.0f})"
                        color = (50, 210, 100)
                        recognized_names.append(recognized_person)
                    else:
                        unknown_seen = True
                        closest_name = self.label_names.get(label, "registered face")
                        name = f"Unknown ({closest_name}, d={distance:.0f})"
                except Exception:
                    unknown_seen = True
            else:

                unknown_seen = True

                name = "Unknown - register faces"

            cv2.rectangle(display, (x, y), (x + fw, y + fh), color, 2)

            cv2.putText(display, name, (x, max(25, y - 8)), cv2.FONT_HERSHEY_SIMPLEX, 0.65, color, 2)



        if len(detected):

            self.last_face_seen = now

            if recognized_names:

                self.person_var.set("Recognized: " + ", ".join(sorted(set(recognized_names))) + " | LBPH match accepted")

                # An authorized face resets the sequence of failed unknown sessions.

                self.failed_attempts = 0

                self.failures_var.set(f"{self.failed_attempts} / {FAILURES_TO_RECORD}")

                self.unknown_in_current_session = False

            elif unknown_seen and not self.registration_running and not self.unknown_in_current_session:

                self.failed_attempts += 1

                self.failures_var.set(f"{self.failed_attempts} / {FAILURES_TO_RECORD}")

                self.unknown_in_current_session = True

                self._log(f"Unknown face attempt {self.failed_attempts}/{FAILURES_TO_RECORD}.")

                if self.failed_attempts >= FAILURES_TO_RECORD:

                    self._start_recording(frame)

        else:

            self.person_var.set("No face detected" if not self.registration_running else f"Registering: {len(self.registration_samples)}/{SAMPLES_TO_CAPTURE}")

            if now - self.last_face_seen > 2.0:

                self.unknown_in_current_session = False



        if self.registration_running and len(detected):
            api_face_state = "REGISTERING"
            api_person = ""
        elif recognized_names:
            api_face_state = "RECOGNIZED"
            api_person = ", ".join(sorted(set(recognized_names)))
        elif len(detected):
            api_face_state = "UNKNOWN"
            api_person = ""
        else:
            api_face_state = "NO_FACE"
            api_person = ""

        status_update = dict(
            camera_connected=bool(self.camera_running),
            model_ready=bool(self.model_ready),
            face_state=api_face_state,
            recognized_person=api_person,
            last_face_update=now,
            recording=bool(self.recording),
            recording_file=os.path.basename(self.recording_path) if self.recording_path else "",
            failed_attempts=int(self.failed_attempts),
        )
        if api_face_state == "RECOGNIZED" and api_person:
            status_update["last_recognized_person"] = api_person
            status_update["last_recognition_update"] = now
        self._update_api_status(**status_update)

        if self.recording and self.video_writer is not None:

            self.video_writer.write(frame)

            cv2.putText(display, "SECURITY RECORDING ACTIVE", (16, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

        return display



    def _refresh_video(self):

        if self.closing:

            return

        frame = None

        if self.camera_running and self.camera is not None:

            try:

                ok, raw = self.camera.read()

                if ok and raw is not None:

                    with self.frame_lock:

                        self.latest_frame = raw

                with self.frame_lock:

                    frame = self.latest_frame.copy() if self.latest_frame is not None else None

            except Exception as exc:

                self._log("Camera read error: " + str(exc))

                self._disconnect_camera()

        if frame is not None:

            try:

                display = self._process_frame(frame)

                rgb = cv2.cvtColor(display, cv2.COLOR_BGR2RGB)

                image = Image.fromarray(rgb)

                image.thumbnail((850, 520), Image.Resampling.LANCZOS)

                photo = ImageTk.PhotoImage(image=image)

                self.video_label.configure(image=photo, text="", width=0, height=0)

                self.video_label.image = photo

            except Exception as exc:

                self._log("Frame processing error: " + str(exc))

        self.video_job = self.root.after(30, self._refresh_video)



    def close(self):

        self.closing = True

        if self.video_job is not None:

            try:

                self.root.after_cancel(self.video_job)

            except Exception:

                pass

        self._disconnect_camera(log_event=False)

        self.stop_recording()

        if hasattr(self, "event_server"):
            self.event_server.close()

        self.root.destroy()





def main():

    root = tk.Tk()

    try:

        SmartDoorDashboard(root)

    except Exception as exc:

        messagebox.showerror("SmartDoor startup error", str(exc), parent=root)

        root.destroy()

        raise

    root.mainloop()





if __name__ == "__main__":

    main()
