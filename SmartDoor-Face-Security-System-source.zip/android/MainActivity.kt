package com.example.smartdoorlock

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothGattService
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.util.UUID
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

class MainActivity : FragmentActivity() {

    private val serviceUuid = UUID.fromString(
        "12345678-1234-1234-1234-123456789abc"
    )

    private val characteristicUuid = UUID.fromString(
        "abcdefab-1234-1234-1234-abcdefabcdef"
    )

    private val handler = Handler(Looper.getMainLooper())

    private var gatt: BluetoothGatt? = null
    private var writeCharacteristic: BluetoothGattCharacteristic? = null
    private var scanner: BluetoothLeScanner? = null

    private var scanning = false
    private var connectionStarted = false
    private var connected = false

    private var uiStatus by mutableStateOf(
        "Ready. Tap Connect to ESP32."
    )

    private var accessMessage by mutableStateOf(
        "Connect to ESP32, then verify face or fingerprint."
    )

    // Replace the IP address with your PC's IPv4 address from `ipconfig`.
    private var pcServerAddress by mutableStateOf("http://192.168.1.100:8765")

    private var pcFaceStatus by mutableStateOf("PC face recognition: not checked yet.")
    private var pcRecordingStatus by mutableStateOf("PC recording status: not checked yet.")

    private fun updateStatus(message: String) {
        runOnUiThread {
            uiStatus = message
        }
    }

    private fun updateAccess(message: String) {
        runOnUiThread {
            accessMessage = message
        }
    }

    private fun hasBluetoothPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.BLUETOOTH_CONNECT
                    ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions(
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                ),
                100
            )
        } else {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                100
            )
        }
    }

    @SuppressLint("MissingPermission")
    private fun startScan() {
        if (!hasBluetoothPermissions()) {
            updateStatus("Grant Bluetooth permissions, then tap Connect again.")
            requestBluetoothPermissions()
            return
        }

        val manager =
            getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager

        val adapter = manager.adapter
        if (adapter == null) {
            updateStatus("ERROR: Bluetooth adapter unavailable.")
            return
        }

        if (!adapter.isEnabled) {
            updateStatus("ERROR: Turn on Bluetooth on your phone.")
            return
        }

        stopScan()

        try {
            gatt?.close()
        } catch (_: Exception) {
        }

        gatt = null
        writeCharacteristic = null
        connected = false
        connectionStarted = false

        scanner = adapter.bluetoothLeScanner

        if (scanner == null) {
            updateStatus("ERROR: BLE scanner unavailable.")
            return
        }

        updateStatus("Scanning for ESP32_DOOR_LOCK...")
        scanning = true

        try {
            scanner?.startScan(scanCallback)

            handler.postDelayed({
                if (scanning) {
                    stopScan()
                    updateStatus(
                        "SCAN TIMEOUT: No matching ESP32 found. Check advertising and permissions."
                    )
                }
            }, 15000)

        } catch (e: Exception) {
            scanning = false
            updateStatus("SCAN ERROR: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() {
        if (scanning) {
            try {
                scanner?.stopScan(scanCallback)
            } catch (_: Exception) {
            }
        }
        scanning = false
    }

    private val scanCallback = object : ScanCallback() {

        @SuppressLint("MissingPermission")
        override fun onScanResult(
            callbackType: Int,
            result: ScanResult
        ) {
            val device = result.device

            val deviceName = try {
                device.name
            } catch (_: Exception) {
                null
            }

            val advertisedName = result.scanRecord?.deviceName
            val advertisedServices =
                result.scanRecord?.serviceUuids?.map { it.uuid }

            val nameMatches =
                deviceName == "ESP32_DOOR_LOCK" ||
                        advertisedName == "ESP32_DOOR_LOCK"

            val serviceMatches =
                advertisedServices?.contains(serviceUuid) == true

            if (!nameMatches && !serviceMatches) {
                val foundName =
                    advertisedName ?: deviceName ?: "(name not advertised)"
                updateStatus("Scanning... detected: $foundName")
                return
            }

            if (connectionStarted) return

            connectionStarted = true
            stopScan()
            updateStatus("ESP32 FOUND. Connecting...")

            try {
                gatt?.close()

                gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    device.connectGatt(
                        this@MainActivity,
                        false,
                        gattCallback,
                        BluetoothDevice.TRANSPORT_LE
                    )
                } else {
                    device.connectGatt(
                        this@MainActivity,
                        false,
                        gattCallback
                    )
                }

                if (gatt == null) {
                    connectionStarted = false
                    updateStatus("ERROR: connectGatt returned null.")
                }
            } catch (e: Exception) {
                connectionStarted = false
                updateStatus("CONNECT ERROR: ${e.message}")
            }
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>) {
            results.forEach { onScanResult(0, it) }
        }

        override fun onScanFailed(errorCode: Int) {
            scanning = false
            connectionStarted = false
            updateStatus("SCAN FAILED. Error code: $errorCode")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {

        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(
            bluetoothGatt: BluetoothGatt,
            status: Int,
            newState: Int
        ) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                connected = false
                writeCharacteristic = null
                updateStatus("GATT CONNECTION FAILED. Status: $status")

                bluetoothGatt.close()
                if (gatt === bluetoothGatt) gatt = null
                connectionStarted = false
                return
            }

            when (newState) {
                BluetoothGatt.STATE_CONNECTED -> {
                    connected = true
                    updateStatus("CONNECTED. Discovering services...")

                    val started = try {
                        bluetoothGatt.discoverServices()
                    } catch (_: Exception) {
                        false
                    }

                    if (!started) {
                        updateStatus("ERROR: Could not start service discovery.")
                    }
                }

                BluetoothGatt.STATE_DISCONNECTED -> {
                    connected = false
                    writeCharacteristic = null
                    connectionStarted = false
                    updateStatus("DISCONNECTED. Tap Connect to retry.")

                    bluetoothGatt.close()
                    if (gatt === bluetoothGatt) gatt = null
                }
            }
        }

        override fun onServicesDiscovered(
            bluetoothGatt: BluetoothGatt,
            status: Int
        ) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                updateStatus("SERVICE DISCOVERY FAILED. Status: $status")
                return
            }

            val service: BluetoothGattService? =
                bluetoothGatt.getService(serviceUuid)

            if (service == null) {
                updateStatus("CONNECTED, BUT SERVICE UUID NOT FOUND.")
                return
            }

            val characteristic =
                service.getCharacteristic(characteristicUuid)

            if (characteristic == null) {
                updateStatus(
                    "SERVICE FOUND, BUT CHARACTERISTIC UUID NOT FOUND."
                )
                return
            }

            writeCharacteristic = characteristic
            updateStatus("CONNECTED. Service and characteristic found!")
        }

        override fun onCharacteristicWrite(
            bluetoothGatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                updateStatus("Command sent successfully.")
            } else {
                updateStatus("COMMAND WRITE FAILED. Status: $status")
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun sendCommand(command: String) {
        val currentGatt = gatt
        val characteristic = writeCharacteristic

        if (!connected || currentGatt == null || characteristic == null) {
            updateStatus("Not connected. Connect to ESP32 first.")
            return
        }

        val properties = characteristic.properties

        val writeType = when {
            (properties and
                    BluetoothGattCharacteristic.PROPERTY_WRITE) != 0 ->
                BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT

            (properties and
                    BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0 ->
                BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE

            else -> {
                updateStatus("ERROR: Characteristic does not support writing.")
                return
            }
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val result = currentGatt.writeCharacteristic(
                    characteristic,
                    command.toByteArray(Charsets.UTF_8),
                    writeType
                )

                if (result != android.bluetooth.BluetoothStatusCodes.SUCCESS) {
                    updateStatus("COMMAND WRITE FAILED TO START. Code: $result")
                } else {
                    updateStatus("Sending command: $command...")
                }
            } else {
                @Suppress("DEPRECATION")
                characteristic.value = command.toByteArray(Charsets.UTF_8)

                @Suppress("DEPRECATION")
                characteristic.writeType = writeType

                @Suppress("DEPRECATION")
                val started = currentGatt.writeCharacteristic(characteristic)

                if (started) {
                    updateStatus("Sending command: $command...")
                } else {
                    updateStatus("COMMAND WRITE FAILED TO START.")
                }
            }
        } catch (e: Exception) {
            updateStatus("WRITE ERROR: ${e.message}")
        }
    }

    private fun pcRequest(
        path: String,
        method: String = "GET",
        body: String? = null,
        onResult: (Int, String) -> Unit
    ) {
        val baseUrl = pcServerAddress.trim().trimEnd('/')
        if (baseUrl.isBlank()) {
            updateStatus("Enter your PC security server URL first.")
            return
        }

        Thread {
            var connection: HttpURLConnection? = null
            var code = -1
            var response = ""
            try {
                connection = (URL("$baseUrl$path").openConnection() as HttpURLConnection).apply {
                    requestMethod = method
                    connectTimeout = 4000
                    readTimeout = 4000
                    setRequestProperty("Accept", "application/json")
                    if (body != null) {
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    }
                }
                if (body != null) {
                    connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                }
                code = connection.responseCode
                val stream = if (code in 200..399) connection.inputStream else connection.errorStream
                if (stream != null) {
                    response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                }
            } catch (e: Exception) {
                response = e.message ?: "Network connection failed"
            } finally {
                connection?.disconnect()
            }

            val resultCode = code
            val resultText = response
            runOnUiThread { onResult(resultCode, resultText) }
        }.start()
    }

    private fun checkPcStatus() {
        updateStatus("Checking PC face-recognition dashboard...")
        pcRequest("/status") { code, response ->
            if (code !in 200..299) {
                pcFaceStatus = "PC face status unavailable (HTTP $code)."
                updateStatus("PC server returned HTTP $code. Check the dashboard and URL.")
                return@pcRequest
            }
            try {
                val data = JSONObject(response)
                val camera = data.optBoolean("camera_connected", false)
                val model = data.optBoolean("model_ready", false)
                val state = data.optString("face_state", "UNKNOWN")
                val person = data.optString("recognized_person", "")
                val failures = data.optInt("failed_attempts", 0)
                val recording = data.optBoolean("recording", false)
                val recordingFile = data.optString("recording_file", "")

                pcFaceStatus = "PC camera: ${if (camera) "ONLINE" else "OFFLINE"}\n" +
                    "Face model: ${if (model) "READY" else "NOT TRAINED"}\n" +
                    "Face status: $state" + if (person.isNotBlank()) " ($person)" else ""
                pcRecordingStatus = if (recording) {
                    "Recording: ACTIVE" + if (recordingFile.isNotBlank()) " — $recordingFile" else ""
                } else {
                    "Recording: OFF | Failed attempts: $failures"
                }
                updateStatus("PC dashboard status received.")
            } catch (e: Exception) {
                pcFaceStatus = "Could not read PC status response."
                updateStatus("Invalid response from PC server: ${e.message}")
            }
        }
    }

    private fun verifyFaceWithPython() {
        updateStatus("Checking the live face visible to the PC camera...")
        pcRequest("/face-check") { code, response ->
            if (code !in 200..299) {
                updateAccess("FACE CHECK UNAVAILABLE")
                updateStatus("PC face check failed (HTTP $code).")
                return@pcRequest
            }
            try {
                val data = JSONObject(response)
                val camera = data.optBoolean("camera_connected", false)
                val model = data.optBoolean("model_ready", false)
                val state = data.optString("face_state", "UNKNOWN")
                val name = data.optString("recognized_person", "")
                val eligible = data.optBoolean("eligible", false)
                val faceStateFresh = data.optBoolean("face_state_fresh", false)

                pcFaceStatus = "PC camera: ${if (camera) "ONLINE" else "OFFLINE"}\n" +
                    "Face model: ${if (model) "READY" else "NOT TRAINED"}\n" +
                    "Face status: $state" + if (name.isNotBlank()) " ($name)" else ""

                when {
                    !camera -> {
                        updateAccess("PC CAMERA OFFLINE")
                        updateStatus("Start the PC dashboard and connect its camera first.")
                    }
                    !model -> {
                        updateAccess("FACE MODEL NOT READY")
                        updateStatus("Register authorized faces and train the model on the PC dashboard.")
                    }
                    eligible && name.isNotBlank() -> {
                        if (connected && writeCharacteristic != null) {
                            updateAccess("ACCESS GRANTED — SOURCE: FACE ID — $name")
                            sendCommand("FACE_GRANTED")
                            updateStatus("PC face model recognized $name; FACE_GRANTED sent to ESP32.")
                        } else {
                            updateAccess("FACE RECOGNIZED — $name")
                            updateStatus("Face matched, but connect to ESP32 before requesting unlock.")
                        }
                    }
                    state == "UNKNOWN" && faceStateFresh -> {
                        updateAccess("ID IS WRONG — SOURCE: FACE ID")
                        if (connected && writeCharacteristic != null) sendCommand("FACE_DENIED")
                        notifyPcFailedAttempt("face")
                        updateStatus("Unknown face attempt. OLED alert sent; PC security recording requested.")
                    }
                    state == "REGISTERING" -> {
                        updateAccess("FACE REGISTRATION IN PROGRESS")
                        updateStatus("Finish face registration from the PC dashboard.")
                    }
                    else -> {
                        updateAccess("NO FACE DETECTED")
                        updateStatus("No current face is visible. Look at the PC camera and tap Verify Face again.")
                    }
                }
            } catch (e: Exception) {
                updateAccess("FACE CHECK ERROR")
                updateStatus("Could not read face-check response: ${e.message}")
            }
        }
    }

    private fun requestPcRecording(start: Boolean) {
        val path = if (start) "/recording/start" else "/recording/stop"
        pcRequest(path, "POST", "{}") { code, response ->
            if (code in 200..299) {
                pcRecordingStatus = if (start) {
                    "Recording start requested from the PC dashboard..."
                } else {
                    "Recording stop requested from the PC dashboard..."
                }
                updateStatus(if (start) "Asked PC to start security recording." else "Asked PC to stop security recording.")
                handler.postDelayed({ checkPcStatus() }, 700)
            } else {
                pcRecordingStatus = "Recording request failed (HTTP $code)."
                updateStatus("PC recording request failed. Check URL and dashboard.")
            }
        }
    }

    private fun notifyPcFailedAttempt(method: String) {
        val normalizedMethod = if (method == "face") "face" else "fingerprint"
        val eventName = if (normalizedMethod == "face") "face_not_recognized" else "fingerprint_not_recognized"
        val recordingCommand = if (normalizedMethod == "face") "FACE_RECORDING" else "FINGER_RECORDING"
        val failedCommand = if (normalizedMethod == "face") "FACE_RECORD_FAILED" else "FINGER_RECORD_FAILED"
        val baseUrl = pcServerAddress.trim().trimEnd('/')
        Thread {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL("$baseUrl/failed-auth").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 3000
                    readTimeout = 3000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val body = """{"event":"$eventName","method":"$normalizedMethod"}"""
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                runOnUiThread {
                    if (code in 200..299) {
                        if (connected && writeCharacteristic != null) sendCommand(recordingCommand)
                        pcRecordingStatus = "Failed $normalizedMethod authentication reported; recording requested."
                        updateStatus("Failed $normalizedMethod authentication reported to PC; recording was requested.")
                        handler.postDelayed({ checkPcStatus() }, 700)
                    } else {
                        if (connected && writeCharacteristic != null) sendCommand(failedCommand)
                        updateStatus("PC security server returned HTTP $code; recording request failed.")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (connected && writeCharacteristic != null) sendCommand(failedCommand)
                    updateStatus("Could not notify PC. Check PC IP, Wi-Fi, firewall and dashboard.")
                }
            } finally {
                connection?.disconnect()
            }
        }.start()
    }

    private fun authenticateFingerprint() {
        val authenticators =
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.BIOMETRIC_WEAK

        if (
            BiometricManager.from(this).canAuthenticate(authenticators) !=
            BiometricManager.BIOMETRIC_SUCCESS
        ) {
            updateAccess("AUTHENTICATION UNAVAILABLE")
            updateStatus("Register a fingerprint in phone Settings first.")
            return
        }

        if (!connected || writeCharacteristic == null) {
            updateAccess("NOT CONNECTED")
            updateStatus("Connect to ESP32 before authenticating.")
            return
        }

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Smart Door Lock")
            .setSubtitle("Verify your fingerprint to request access")
            .setNegativeButtonText("Cancel")
            .setAllowedAuthenticators(authenticators)
            .build()

        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {

                override fun onAuthenticationSucceeded(
                    result: BiometricPrompt.AuthenticationResult
                ) {
                    updateAccess("ACCESS GRANTED — SOURCE: FINGERPRINT")
                    sendCommand("FINGER_GRANTED")
                }

                override fun onAuthenticationFailed() {
                    updateAccess("ID IS WRONG — SOURCE: FINGERPRINT")
                    sendCommand("FINGER_DENIED")
                    notifyPcFailedAttempt("fingerprint")
                }

                override fun onAuthenticationError(
                    errorCode: Int,
                    errString: CharSequence
                ) {
                    updateAccess("AUTHENTICATION CANCELLED")
                    updateStatus("Authentication ended: $errString")
                }
            }
        )

        updateAccess("Waiting for fingerprint...")
        prompt.authenticate(promptInfo)
    }

    @SuppressLint("MissingPermission")
    private fun disconnect() {
        stopScan()
        writeCharacteristic = null
        connected = false
        connectionStarted = false

        val oldGatt = gatt
        gatt = null

        try {
            oldGatt?.disconnect()
            oldGatt?.close()
        } catch (_: Exception) {
        }

        updateStatus("Disconnected.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Smart Door Lock",
                            style = MaterialTheme.typography.headlineMedium
                        )

                        OutlinedTextField(
                            value = pcServerAddress,
                            onValueChange = { pcServerAddress = it },
                            label = { Text("PC security server URL") },
                            supportingText = { Text("Use your PC IPv4 address, port 8765") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Text(text = pcFaceStatus, style = MaterialTheme.typography.bodyMedium)
                        Text(text = pcRecordingStatus, style = MaterialTheme.typography.bodyMedium)

                        Button(
                            onClick = { checkPcStatus() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Check PC Face Status")
                        }

                        Button(
                            onClick = { verifyFaceWithPython() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Verify Face & Unlock")
                        }

                        Button(
                            onClick = { requestPcRecording(true) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Start Security Recording")
                        }

                        OutlinedButton(
                            onClick = { requestPcRecording(false) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Stop Security Recording")
                        }

                        Text(
                            text = "Connection status:\n$uiStatus",
                            style = MaterialTheme.typography.bodyLarge
                        )

                        Text(
                            text = accessMessage,
                            style = MaterialTheme.typography.titleMedium,
                            color = when {
                                accessMessage.startsWith("ACCESS GRANTED") ->
                                    androidx.compose.ui.graphics.Color(0xFF16803D)

                                accessMessage.startsWith("ACCESS DENIED") ||
                                        accessMessage.startsWith("ID IS WRONG") ->
                                    androidx.compose.ui.graphics.Color(0xFFD32F2F)

                                else -> MaterialTheme.colorScheme.onSurface
                            }
                        )

                        Button(
                            onClick = { startScan() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Connect to ESP32")
                        }

                        Button(
                            onClick = { authenticateFingerprint() },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = connected && writeCharacteristic != null
                        ) {
                            Text("Authenticate with Fingerprint")
                        }

                        Button(
                            onClick = { sendCommand("LOCK") },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = connected && writeCharacteristic != null
                        ) {
                            Text("Send LOCK Command")
                        }

                        OutlinedButton(
                            onClick = { disconnect() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Disconnect")
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        stopScan()

        try {
            gatt?.close()
        } catch (_: Exception) {
        }

        gatt = null
        writeCharacteristic = null

        super.onDestroy()
    }
}